package org.ordermanagement.speedservices;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpeedservicesApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpeedservicesApplication.class, args);
	}

}
