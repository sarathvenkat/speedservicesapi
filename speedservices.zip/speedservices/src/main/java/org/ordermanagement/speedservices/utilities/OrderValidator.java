package org.ordermanagement.speedservices.utilities;

import org.ordermanagement.speedservices.models.Order;
import org.springframework.stereotype.Component;

@Component
public class OrderValidator 
{

	public boolean orderValidation(Order order)
	{
		if(validateOrderId(order.getOrderId()) && validateOrderName(order.getOrderName()) && validateOrderPrice(order.getOrderPrice()))
		{
			return true;
		}
		
		return false;
	}
	
	public boolean validateOrderId(Long id)
	{
		if(id<=0)
		{
			return false;
		}
		
		return true;
	}
	
	public boolean validateOrderName(String orderName)
	{
		if(orderName.matches("^[^0-9]*$"))
		{
			return false;
		}
		
		return true;
		
	}
	
	public boolean validateOrderPrice(Double price)
	{
		if(price<=0)
		{
			return false;
		}
		
		return true;
	}
}
