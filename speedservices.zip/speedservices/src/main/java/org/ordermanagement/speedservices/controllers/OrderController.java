package org.ordermanagement.speedservices.controllers;

import java.util.List;

import org.ordermanagement.speedservices.models.Order;
import org.ordermanagement.speedservices.service.OrderService;
import org.ordermanagement.speedservices.utilities.OrderValidator;
import org.ordermanagement.speedservices.utilities.URIConstants;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class OrderController {

	@Autowired
	OrderService orderService;
	
	@Autowired
	OrderValidator orderValidator;
			
	
	@RequestMapping(method = RequestMethod.GET,value = URIConstants.ORDER_URL,produces = "application/json")
	public List<Order> getAllOrders() 
	{
		return orderService.getAllOrders();
	}
	
	
	@RequestMapping(method = RequestMethod.POST,value = URIConstants.ORDER_URL,produces = "application/json",consumes="application/json")
	public Order insertOrder(@RequestBody(required=true) Order order)
	{
		
		if(orderValidator.orderValidation(order))		
		return orderService.addOrder(order);	
		
		return null;
	}
	
	@RequestMapping(method = RequestMethod.POST,value = URIConstants.ORDER_URL_ID,produces = "application/json",consumes="application/json")
	public Order modifyOrder(@RequestBody(required=true) Order order,@PathVariable("id") Long id)
	{
		return orderService.updateOrder(order,id);
	}
	
	
	@RequestMapping(method = RequestMethod.GET,value = URIConstants.ORDER_URL_ID,produces = "application/json")
	public Order getOrder(@PathVariable("id") Long id)
	{
		return orderService.getOrder(id);
	}
	
}
