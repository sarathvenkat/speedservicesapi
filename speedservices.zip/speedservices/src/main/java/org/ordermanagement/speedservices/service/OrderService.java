package org.ordermanagement.speedservices.service;

import java.util.List;

import org.ordermanagement.speedservices.dao.OrderRepository;
import org.ordermanagement.speedservices.models.Order;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class OrderService 
{
	
	
	@Autowired
	OrderRepository orderRepo;

	public List<Order> getAllOrders()
	{
		return orderRepo.getAllOrder();		
	}

	public Order addOrder(Order order) {
		
		return orderRepo.addOrder(order) ;
	}
	
	
	public Order updateOrder(Order order,Long id)
	{
		return orderRepo.updateOrder(order,id);
	}

	public Order getOrder(Long id) 
	{
		
		List<Order> orderList = orderRepo.getAllOrder();
			
		return orderList.stream().filter(t -> t.getOrderId()== id).findAny().orElse(null);
				
	}
	
}
