package org.ordermanagement.speedservices.utilities;

public class URIConstants 
{

	public static final String ORDER_URL="ordermanagementapi/v1";
	public static final String ORDER_URL_ID="ordermanagementapi/v1/{id}";
	
	
	
}
