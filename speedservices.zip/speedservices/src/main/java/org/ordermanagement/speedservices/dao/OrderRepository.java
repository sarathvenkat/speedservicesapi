package org.ordermanagement.speedservices.dao;

import java.util.ArrayList;
import java.util.List;

import org.ordermanagement.speedservices.models.Order;
import org.springframework.stereotype.Repository;

@Repository
public class OrderRepository 
{

	List<Order> orderList = new ArrayList<Order>();
	
	public OrderRepository() 
	{
		orderList.add(new Order(4l,"T-Shirt",1068.52));
		orderList.add(new Order(6l,"Krocks",874.60));
		orderList.add(new Order(3l,"Shoes", 792.36));
	}

	public List<Order> getAllOrder() {
			return orderList;
	}

	public Order addOrder(Order order) {
		
		orderList.add(order);
		return order;
	}

	public Order updateOrder(Order order,Long id) {
		
		
		orderList.stream().filter(t -> t.getOrderId() ==id).forEach(t -> {
			t.setOrderName(order.getOrderName());
			t.setOrderPrice(order.getOrderPrice());
		});;
		
		return order;
	}
	
	
	
	
	
	
}
